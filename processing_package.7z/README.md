# NASHVILLE EVENTS PROCESSING

Ths packege is for processing events data to be used in nashville webmap on Rowdybus blog
